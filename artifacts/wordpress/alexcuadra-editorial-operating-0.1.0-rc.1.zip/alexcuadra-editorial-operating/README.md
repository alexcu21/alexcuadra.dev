# Local operating candidate 0.1.0-rc.1

Disabled by default. AC_EDITORIAL_OPERATING_LOCAL=true only permits the previously admitted local experiment; it does not admit a production site. Loading/activation grants no capabilities and performs no DDL, exports or editorial writes. Six MCP abilities register only under explicit local opt-in. CLI controller methods retain their own operator checks. No activation/uninstall or scheduled deletion hooks.

This package is a code-only acceptance candidate, not authorized for installation in the shared CMS. Production admission, remote read-only preflight and deployment/rollback instructions are still pending. Keep the existing backup and all operational records. Deactivation does not undo approved source edits or delete data. Existing rc.2 remains a separate required plugin.
